import { createWorkspaceLayout } from './ui/workspace-layout.js';
import { createInspector } from './ui/inspector.js';
import { createDocumentLists } from './ui/document-lists.js';
import { createSnapshotPanel } from './ui/snapshot-panel.js';
import { createCanvasViewport } from './ui/canvas-viewport.js';
import { createExportDialog } from './ui/export-dialog.js';
import { saveCapture, getDocument, listDocuments } from './db.js';
import { createEditorSession } from './editor-session.js';
import { CanvasScene, copy, validateSnapshot } from './engine.js';
import { buildReview } from './export.js';
import { createEditorController } from './editor-controller.js';
import { createMcpBridge } from './bridge-client.js';
import { createSnapshotHistory } from './snapshot-history.js';

const $ = (selector) => document.querySelector(selector);
const isExtension = typeof chrome !== 'undefined' && !!chrome.runtime?.id;
const state = {
  snapshot: null,
  scene: null,
  undo: [],
  redo: [],
  expanded: new Set(),
  zoom: 1,
  size: { width: 1280, height: 900 },
  saving: Promise.resolve(),
  generation: 0,
  commentTarget: null,
  mode: 'edit',
  ready: false,
  revision: 0,
  lastAction: null,
  lastSaveError: null,
  mcpStatus: { connected: false },
};
const editorId =
  globalThis.crypto?.randomUUID?.() ||
  'editor-' + Date.now() + '-' + Math.random().toString(36).slice(2);
const kinds = {
  text: '텍스트',
  pseudo: '생성된 문구',
  icon: '아이콘',
  raster: '이미지 레이어',
  element: '요소',
};
let toastTimer;
const {
  checkpoint,
  applyCheckpoint,
  historyBefore,
  changeCommitted,
  undo,
  save,
  flushEditor,
  flush,
} = createEditorSession({
  state,
  getNote: () => $('#review-note').value,
  setNote: (value) => {
    $('#review-note').value = value;
  },
  status: (message) => {
    $('#save-status').textContent = message;
  },
  commitCommentDraft,
  render: () => {
    renderInspector();
    renderLayers();
    renderChanges();
    renderHistory();
    renderSnapshots();
    renderMcpStatus();
  },
});
const { panels, setPanelVisibility } = createWorkspaceLayout({ $, commitCommentDraft });
function toast(message) {
  $('#toast').textContent = message;
  $('#toast').hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => ($('#toast').hidden = true), 4000);
}
function editSafely(action) {
  try {
    action();
  } catch (error) {
    toast(error.message);
    renderInspector();
  }
}
function notice(message) {
  $('#notice').textContent = message;
  $('#notice').hidden = !message;
}
function renderHistory() {
  $('#undo').disabled = !state.undo.length;
  $('#redo').disabled = !state.redo.length;
}
function commitCommentDraft() {
  if (state.scene && state.commentTarget)
    state.scene.setComment(state.commentTarget, $('#component-comment').value);
}
const { sizeChanged, zoomTo, fit } = createCanvasViewport({ $, state });
const { renderInspector } = createInspector({ $, state, kinds });
function selectNode(id, { reveal = false } = {}) {
  if (!state.scene) return;
  state.scene.select(id);
  for (const parent of state.scene.ancestors(id)) state.expanded.add(parent);
  renderLayers();
  if (reveal) {
    const r = state.scene.rect(id);
    if (r) {
      $('#viewport').scrollTo({
        left: Math.max(0, r.x * state.zoom - 100),
        top: Math.max(0, r.y * state.zoom - 100),
        behavior: 'smooth',
      });
    }
  }
}
const { renderLayers, renderChanges } = createDocumentLists({ $, state, selectNode, focusComment });
function focusComment() {
  setPanelVisibility('properties', true);
  showSnapshots(false);
  const field = $('#component-comment');
  field.focus({ preventScroll: true });
  field.scrollIntoView({ block: 'nearest' });
}
const snapshotHistory = createSnapshotHistory({
  state,
  checkpoint,
  historyBefore,
  apply: applyCheckpoint,
  changed: changeCommitted,
});
const { showSnapshots, renderSnapshots } = createSnapshotPanel({
  $,
  state,
  snapshotHistory,
  commitCommentDraft,
  setPanelVisibility,
  panels,
  toast,
});
function onKey(event) {
  if (!state.scene || $('#export-dialog').open) return;
  const editing = event.target.closest?.('input,textarea,select');
  if (editing && event.target.ownerDocument === document) return;
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z') {
    event.preventDefault();
    undo(event.shiftKey ? 'redo' : 'undo');
    return;
  }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'y') {
    event.preventDefault();
    undo('redo');
    return;
  }
  if (event.key === 'Escape') {
    state.scene.select(null);
    renderLayers();
    return;
  }
  if (state.mode === 'comment') return;
  if (event.key === 'Delete' || event.key === 'Backspace') {
    if (state.scene.selected) {
      event.preventDefault();
      state.scene.remove();
    }
    return;
  }
  const delta = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[
    event.key
  ];
  if (delta && state.scene.selected) {
    event.preventDefault();
    editSafely(() =>
      state.scene.nudge(delta[0] * (event.shiftKey ? 10 : 1), delta[1] * (event.shiftKey ? 10 : 1)),
    );
  }
}
let opening = Promise.resolve();
function openSnapshot(...args) {
  const next = opening.catch(() => {}).then(() => openDocument(...args));
  opening = next;
  return next;
}
async function openDocument(snapshot, edits = {}, note = '', annotations = {}, timeline = null) {
  validateSnapshot(snapshot);
  await flushEditor();
  await saveCapture(snapshot);
  const generation = ++state.generation;
  commitCommentDraft();
  state.commentTarget = null;
  state.ready = false;
  state.revision++;
  $('#welcome').hidden = true;
  $('#artboard-space').hidden = false;
  $('#export-button').disabled = true;
  $('#snapshots-button').disabled = true;
  const {
    timeline: storedTimeline,
    edits: storedEdits,
    annotations: storedComments,
    note: storedNote,
    ...capture
  } = snapshot;
  timeline = timeline || storedTimeline;
  state.timeline = null;
  state.snapshot = capture;
  state.undo = [];
  state.redo = [];
  state.expanded = new Set(snapshot.nodes.filter((node) => !node.parentId).map((node) => node.id));
  $('#source-title').textContent = snapshot.source.title || '가져온 화면';
  $('#document-title').textContent = snapshot.source.title || '가져온 화면';
  $('#source-url').textContent = snapshot.source.url;
  try {
    const url = new URL(snapshot.source.url);
    $('#source-url').href = /^https?:$/.test(url.protocol) ? url.href : '#';
  } catch {
    $('#source-url').href = '#';
  }
  $('#source-url').hidden = false;
  $('#source-meta').textContent =
    snapshot.source.viewport.width +
    ' × ' +
    snapshot.source.viewport.height +
    ' · ' +
    snapshot.nodes.length.toLocaleString() +
    '개 요소';
  $('#review-note').value = note;
  $('#artboard-label').textContent =
    (snapshot.source.title || '화면') + ' / ' + snapshot.source.viewport.width + ' px';
  const scene = new CanvasScene($('#scene-frame'), snapshot, {
    onSelect: (id) => {
      if (id !== state.commentTarget) commitCommentDraft();
      if (state.scene && id)
        for (const parent of state.scene.ancestors(id)) state.expanded.add(parent);
      renderInspector();
      renderLayers();
    },
    onCommentSelect: focusComment,
    onSize: sizeChanged,
    onBeforeChange: historyBefore,
    onLiveChange: renderInspector,
    onCommit: changeCommitted,
    onKey,
  });
  state.scene = scene;
  try {
    await scene.mount();
    if (generation !== state.generation) return;
    scene.interactionMode = state.mode;
    scene.setComments(annotations);
    scene.setEdits(edits);
    snapshotHistory.initialise(timeline);
    fit();
    $('#viewport').scrollLeft = (snapshot.source.scroll?.x || 0) * state.zoom;
    $('#viewport').scrollTop = (snapshot.source.scroll?.y || 0) * state.zoom;
    renderInspector();
    renderLayers();
    renderChanges();
    renderHistory();
    renderSnapshots();
    $('#export-button').disabled = false;
    $('#snapshots-button').disabled = false;
    $('#capture-notes').hidden = !snapshot.warnings.length;
    $('#capture-notes-title').textContent = '가져오기 참고 ' + snapshot.warnings.length + '건';
    $('#capture-notes-list').replaceChildren();
    for (const warning of snapshot.warnings) {
      const li = document.createElement('li');
      li.textContent = warning.message;
      $('#capture-notes-list').append(li);
    }
    state.ready = true;
    connectDesktopIfReady();
    renderMcpStatus();
    save();
    toast('화면을 가져왔어요. 요소를 옮기거나 주석으로 수정 방향을 남겨 보세요.');
  } catch (error) {
    state.snapshot = null;
    state.scene = null;
    state.ready = false;
    notice(error.message);
    $('#welcome').hidden = false;
    $('#artboard-space').hidden = true;
    throw error;
  }
}
async function loadSample() {
  const button = $('#sample-button');
  button.disabled = true;
  button.textContent = '콘솔 화면을 가져오는 중…';
  let source;
  try {
    if (window.CONSOLE_CANVAS_SAMPLE) {
      await openSnapshot(copy(window.CONSOLE_CANVAS_SAMPLE));
      return;
    }
    source = document.createElement('iframe');
    source.width = '1360';
    source.height = '980';
    source.style.cssText = 'position:fixed;left:-20000px;top:0;width:1360px;height:980px;border:0';
    source.src = 'fixtures/console.html';
    const loaded = new Promise((resolve, reject) => {
      source.onload = resolve;
      source.onerror = () => reject(new Error('샘플 화면을 열지 못했습니다.'));
    });
    document.body.append(source);
    await loaded;
    const snapshot = await globalThis.UICloneCapture.capture(source.contentDocument);
    await openSnapshot(snapshot);
  } catch (error) {
    notice(error.message);
  } finally {
    source?.remove();
    button.disabled = false;
    button.textContent = '샘플 콘솔로 시작 →';
  }
}
async function importFile(file) {
  if (!file) return;
  if (file.size > 85_000_000)
    throw new Error('파일이 너무 큽니다. 85MB 이하의 화면 파일을 선택해 주세요.');
  const data = JSON.parse(await file.text());
  if (data.format === 'console-canvas-review') {
    await openSnapshot(
      data.snapshot,
      data.edits,
      data.note || '',
      data.annotations || {},
      data.timeline,
    );
  } else
    await openSnapshot(
      data,
      data.edits || {},
      data.note || '',
      data.annotations || {},
      data.timeline,
    );
}
$('#file-input').addEventListener('change', (event) => {
  importFile(event.target.files[0]).catch((error) =>
    notice('파일을 열지 못했습니다: ' + error.message),
  );
  event.target.value = '';
});
for (const id of ['#import-button', '#welcome-import'])
  $(id).addEventListener('click', () => $('#file-input').click());
$('#installation-button').addEventListener('click', () => {
  $('#import-guide').hidden = !$('#import-guide').hidden;
});
$('#sample-button').addEventListener('click', loadSample);
$('#layer-search').addEventListener('input', renderLayers);
$('#component-comment').addEventListener('input', () => {
  $('#comment-status').textContent = '작성 중 · 저장하거나 다른 요소를 선택하면 기록됩니다.';
  $('#clear-comment').disabled =
    !$('#component-comment').value.trim() && !state.scene?.annotations[state.commentTarget];
});
$('#component-comment').addEventListener('change', commitCommentDraft);
$('#save-comment').addEventListener('click', () => {
  commitCommentDraft();
  renderInspector();
});
$('#clear-comment').addEventListener('click', () => {
  $('#component-comment').value = '';
  commitCommentDraft();
  renderInspector();
});
$('#comment-mode').addEventListener('click', () => {
  commitCommentDraft();
  state.mode = state.mode === 'comment' ? 'edit' : 'comment';
  if (state.scene) state.scene.interactionMode = state.mode;
  $('#comment-mode').setAttribute('aria-pressed', String(state.mode === 'comment'));
  $('#canvas-hint').textContent =
    state.mode === 'comment'
      ? '요소 클릭 → 오른쪽에 주석 작성 · 드래그로 이동하지 않습니다.'
      : '클릭해서 선택 · 드래그해서 이동 · Shift+클릭으로 상위 요소 선택';
  renderInspector();
});
$('#undo').addEventListener('click', () => undo());
$('#redo').addEventListener('click', () => undo('redo'));
$('#select-parent').addEventListener('click', () =>
  selectNode(state.scene.parent(state.scene.selected)),
);
$('#delete').addEventListener('click', () => state.scene?.remove());
$('#inspector-delete').addEventListener('click', () => state.scene?.remove());
for (const button of document.querySelectorAll('[data-nudge]'))
  button.addEventListener('click', () => {
    const delta = { left: [-8, 0], up: [0, -8], down: [0, 8], right: [8, 0] }[button.dataset.nudge];
    editSafely(() => state.scene?.nudge(...delta));
  });
for (const id of ['#offset-x', '#offset-y'])
  $(id).addEventListener('change', () =>
    editSafely(() =>
      state.scene?.setPosition(Number($('#offset-x').value), Number($('#offset-y').value)),
    ),
  );
$('#zoom').addEventListener('change', (event) => zoomTo(Number(event.target.value)));
$('#zoom-in').addEventListener('click', () => zoomTo(state.zoom + 0.1));
$('#zoom-out').addEventListener('click', () => zoomTo(state.zoom - 0.1));
$('#fit').addEventListener('click', fit);
$('#viewport').addEventListener(
  'wheel',
  (event) => {
    if (event.ctrlKey || event.metaKey) {
      event.preventDefault();
      zoomTo(state.zoom + (event.deltaY > 0 ? -0.05 : 0.05));
    }
  },
  { passive: false },
);
document.addEventListener('keydown', onKey);
$('#review-note').addEventListener('change', () => changeCommitted({ label: '추가 설명 수정' }));
createExportDialog({ $, state, commitCommentDraft });
window.addEventListener('dragover', (event) => {
  if (event.dataTransfer?.types.includes('Files')) event.preventDefault();
});
window.addEventListener('drop', (event) => {
  if (event.dataTransfer?.files.length) {
    event.preventDefault();
    importFile(event.dataTransfer.files[0]).catch((error) => notice(error.message));
  }
});
function renderMcpStatus() {
  const status = state.mcpStatus;
  $('#mcp-button').textContent = status.connected ? 'MCP 연결됨' : 'MCP 연결';
  $('#mcp-button').classList.toggle('connected', !!status.connected);
  $('#mcp-state').textContent =
    (status.connected ? 'MCP 연결됨 · r' + state.revision : status.message || 'MCP 연결 안 됨') +
    (state.lastAction
      ? ' · ' +
        (state.lastAction.actor === 'agent' ? '에이전트' : '직접 편집') +
        ' ' +
        state.lastAction.label
      : '');
}
const controller = createEditorController({
  state,
  editorId,
  checkpoint,
  historyBefore,
  changeCommitted,
  undo,
  snapshotHistory,
  isBusy: () =>
    $('#export-dialog').open ||
    $('#mcp-dialog').open ||
    document.activeElement === $('#snapshot-name') ||
    !!(
      state.commentTarget &&
      $('#component-comment').value.trim() !== (state.scene?.annotations[state.commentTarget] || '')
    ),
  render: () => {
    renderInspector();
    renderLayers();
    renderChanges();
    renderHistory();
  },
  flush: async () => {
    await flush();
    return true;
  },
});
const mcpBridge = createMcpBridge({
  metadata: controller.metadata,
  execute: controller.execute,
  onStatus: (status) => {
    state.mcpStatus = status;
    renderMcpStatus();
  },
});
$('#mcp-button').addEventListener('click', () => $('#mcp-dialog').showModal());
$('#mcp-connect').addEventListener('click', async () => {
  const button = $('#mcp-connect');
  button.disabled = true;
  try {
    commitCommentDraft();
    await mcpBridge.connect($('#mcp-address').value.trim(), $('#mcp-code').value.trim());
    $('#mcp-code').value = '';
    $('#mcp-dialog').close();
  } catch (error) {
    $('#mcp-message').textContent = error.message;
  } finally {
    button.disabled = false;
  }
});
$('#mcp-disconnect').addEventListener('click', async () => {
  await mcpBridge.disconnect();
  $('#mcp-dialog').close();
});
if (window.ConsoleCanvasDesktop) {
  document.body.classList.add('desktop-editor');
  const tools = $('.canvas-toolbar');
  tools.setAttribute('role', 'toolbar');
  tools.setAttribute('aria-label', '편집 도구');
  const actions = $('.header-actions');
  actions.setAttribute('role', 'group');
  actions.setAttribute('aria-label', '스냅샷과 화면 파일');
  tools.append(actions);
  $('.app-header').hidden = true;
  window.ConsoleCanvasDesktop.onFlush(flushEditor);
  window.ConsoleCanvasDesktop.onSnapshot((value) =>
    openSnapshot(value).catch((error) => notice(error.message)),
  );
  window.ConsoleCanvasDesktop.getConnection()
    .then((connection) => {
      if (connection) {
        state.desktopConnection = connection;
        connectDesktopIfReady();
      }
    })
    .catch((error) => notice(error.message));
}
const params = new URLSearchParams(location.search);
if (params.has('error')) notice(params.get('error'));
if (params.has('id'))
  getDocument(params.get('id'))
    .then((value) => {
      if (!value)
        throw new Error('저장된 화면을 찾을 수 없습니다. 웹사이트에서 다시 가져와 주세요.');
      return openSnapshot(value, value.edits, value.note, value.annotations);
    })
    .catch((error) => notice(error.message));
else if (params.has('sample')) loadSample();
else
  listDocuments()
    .then((values) => {
      for (const snapshot of values.slice(0, 4)) {
        const button = document.createElement('button');
        button.className = 'recent-item';
        const title = document.createElement('span');
        title.textContent = snapshot.title;
        const date = document.createElement('small');
        date.textContent = new Date(snapshot.capturedAt).toLocaleDateString('ko-KR');
        button.append(title, date);
        button.addEventListener('click', () =>
          getDocument(snapshot.id)
            .then((value) => openSnapshot(value, value.edits, value.note, value.annotations))
            .catch((error) => notice(error.message)),
        );
        $('#recent-documents').append(button);
      }
    })
    .catch(() => {});
// Exposed for the local integration harness; contains only this editor's current document.
window.ConsoleCanvas = {
  state,
  openSnapshot,
  importFile,
  undo,
  selectNode,
  controller,
  snapshotHistory,
  buildReview: () =>
    buildReview(state.snapshot, state.scene, $('#review-note').value, undefined, state.timeline),
};
function connectDesktopIfReady() {
  if (state.desktopConnection && state.ready && !mcpBridge.isConnected()) {
    const connection = state.desktopConnection;
    state.desktopConnection = null;
    mcpBridge.connect(connection.url, connection.token).catch((error) => notice(error.message));
  }
}
