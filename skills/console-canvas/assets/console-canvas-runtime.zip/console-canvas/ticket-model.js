import { semanticState } from './semantic-state.js';
import { transact } from './db.js';
export const TICKET_STATES = {
  draft: '준비 중',
  queued: '구현 대기',
  working: '작업 중',
  review: '검토 대기',
  done: '완료',
  blocked: '확인 필요',
};
function invalid(message, code = 'invalid_ticket') {
  const e = new Error(message);
  e.code = code;
  throw e;
}
function text(value, label, max = 12000, required = true) {
  if (typeof value !== 'string' || value.length > max || (required && !value.trim()))
    invalid(label + '을 확인해 주세요.');
  return value.trim();
}
export function projectKey(value) {
  return text(value, '프로젝트', 300);
}
function stable(value) {
  if (Array.isArray(value)) return value.map(stable);
  if (value && typeof value === 'object')
    return Object.fromEntries(
      Object.keys(value)
        .sort()
        .map((k) => [k, stable(value[k])]),
    );
  return value;
}
export async function fingerprint(value) {
  const bytes = new TextEncoder().encode(JSON.stringify(stable(value)));
  return [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))]
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}
export async function ticketImage(value) {
  if (
    typeof value !== 'string' ||
    value.length > 16_000_000 ||
    !/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(value)
  )
    invalid('12MB 이하의 PNG·JPEG·WebP 이미지를 사용해 주세요.', 'invalid_image');
  const [header, encoded] = value.split(',');
  let raw;
  try {
    raw = atob(encoded);
  } catch {
    invalid('이미지 인코딩이 올바르지 않습니다.', 'invalid_image');
  }
  const png = raw.startsWith('\x89PNG\r\n\x1a\n'),
    jpeg = raw.startsWith('\xff\xd8\xff'),
    webp = raw.startsWith('RIFF') && raw.slice(8, 12) === 'WEBP';
  if (!(
    (header.includes('/png') && png) ||
    (header.includes('/jpeg') && jpeg) ||
    (header.includes('/webp') && webp)
  ))
    invalid('실제 이미지 형식을 확인해 주세요.', 'invalid_image');
  const bytes = Uint8Array.from(raw, (c) => c.charCodeAt(0));
  let width, height;
  if (typeof createImageBitmap === 'function') {
    try {
      const bitmap = await createImageBitmap(
        new Blob([bytes], { type: header.slice(5, header.indexOf(';')) }),
      );
      width = bitmap.width;
      height = bitmap.height;
      bitmap.close();
    } catch {
      invalid('이미지를 읽을 수 없습니다.', 'invalid_image');
    }
    if (!width || !height || width * height > 80_000_000)
      invalid('이미지 표시 크기를 확인해 주세요.', 'invalid_image');
  }
  return { data_url: value, ...(width ? { width, height } : {}) };
}
function operation(value) {
  return text(value, '작업 ID', 160);
}
function metadata(value, label) {
  if (!value || typeof value !== 'object' || JSON.stringify(value).length > 200000)
    invalid(label + ' 크기 또는 형식을 확인해 주세요.');
  return structuredClone(value);
}
export async function validateStoredTicket(t, project_id, document_id) {
  if (
    !t ||
    t.project_id !== project_id ||
    (t.document_id || t.goal?.document_id) !== document_id ||
    !Object.hasOwn(TICKET_STATES, t.status) ||
    !Number.isInteger(t.revision) ||
    t.revision < 0 ||
    !Array.isArray(t.records) ||
    t.records.length > 1000
  )
    invalid('티켓 정보를 확인해 주세요.');
  text(t.id, '티켓 ID', 200);
  text(t.title || t.goal?.title, '티켓 이름', 120);
  if (t.goal) text(t.goal.request, '변경 요청', 12000, false);
  if (!t.goal && !['draft', 'blocked'].includes(t.status)) invalid('확정 목표가 필요합니다.');
  if (!Number.isFinite(Date.parse(t.created_at)) || !Number.isFinite(Date.parse(t.updated_at)))
    invalid('티켓 날짜를 확인해 주세요.');
  if (t.goal) {
    if (t.goal.document_id !== document_id) invalid('목표의 화면 ID가 다릅니다.');
    await ticketImage(t.goal.image?.data_url);
    metadata(t.goal.source || {}, '출처');
    metadata(t.goal.annotations || {}, '주석');
    metadata(t.goal.selection || [], '선택');
  }
  const seen = new Set();
  for (const r of t.records) {
    if (
      !r ||
      seen.has(r.id) ||
      !Object.hasOwn(TICKET_STATES, r.status) ||
      !Number.isFinite(Date.parse(r.at))
    )
      invalid('작업 기록을 확인해 주세요.');
    text(r.id, '기록 ID', 200);
    seen.add(r.id);
    text(r.summary, '작업 기록', 6000);
    if (r.image) await ticketImage(r.image.data_url);
    if (r.checks) text(r.checks, '검증 결과', 6000);
  }
  return t;
}
function now() {
  return new Date().toISOString();
}
export async function ticketReceipt(project_id, operation_id, payload) {
  const key = 'confirm:' + projectKey(project_id) + ':' + operation(operation_id),
    hash = await fingerprint(payload);
  return transact(['tickets', 'operations'], 'readonly', (tx, done) => {
    const r = tx.objectStore('operations').get(key);
    r.onsuccess = () => {
      if (!r.result) return done(null);
      if (r.result.hash !== hash) {
        tx.failure = Object.assign(new Error('다른 요청에서 사용한 작업 ID입니다.'), {
          code: 'operation_id_reused',
        });
        tx.abort();
        return;
      }
      done(r.result.result);
    };
  });
}
function receiptResult(t) {
  // Preserve the acknowledged effect without duplicating raster bytes on each status write.
  const image = (value) => (value ? { ...value, data_url: undefined } : value);
  return {
    ...t,
    goal: t.goal ? { ...t.goal, semantic_state: undefined, image: image(t.goal.image) } : null,
    records: t.records.map((r) => ({ ...r, ...(r.image ? { image: image(r.image) } : {}) })),
  };
}
async function mutate(key, payload, work) {
  const hash = await fingerprint(payload);
  return transact(
    ['tickets', 'operations', 'settings', 'captures', 'sessions', 'documents'],
    'readwrite',
    (tx, done) => {
      const request = tx.objectStore('operations').get(key);
      request.onsuccess = () => {
        if (request.result) {
          if (request.result.hash !== hash) {
            tx.failure = Object.assign(new Error('다른 요청에서 사용한 작업 ID입니다.'), {
              code: 'operation_id_reused',
            });
            tx.abort();
            return;
          }
          done(request.result.result);
          return;
        }
        work(tx, (result) => {
          const document = tx.objectStore('documents').get(result.document_id);
          document.onsuccess = () => {
            if (document.result)
              tx.objectStore('documents').put({ ...document.result, updatedAt: result.updated_at });
          };
          tx.objectStore('operations').put({
            id: key,
            hash,
            ticket_id: result.id,
            result: receiptResult(result),
          });
          done(result);
        });
      };
    },
  );
}
export async function confirmTicketGoal(input) {
  const project_id = projectKey(input.project_id),
    op = operation(input.operation_id);
  if (input.selection_confirmed !== true)
    invalid('사람이 선택한 목표만 확정할 수 있습니다.', 'selection_required');
  const image = await ticketImage(input.image_data_url),
    request = text(input.request || '', '변경 요청', 12000, false);
  let thumbnail;
  try {
    if (typeof createImageBitmap === 'function') {
      const bitmap = await createImageBitmap(await (await fetch(image.data_url)).blob());
      const canvas = document.createElement('canvas');
      canvas.width = 240;
      canvas.height = 150;
      canvas.getContext('2d').drawImage(bitmap, 0, 0, bitmap.width, bitmap.height, 0, 0, 240, 150);
      bitmap.close();
      thumbnail = canvas.toDataURL('image/jpeg', 0.65);
    }
  } catch {
    /* A thumbnail is optional and never gates work. */
  }
  return mutate(
    'confirm:' + project_id + ':' + op,
    input.operation_payload || input,
    (tx, done) => {
      const r = tx.objectStore('tickets').get(input.ticket_id);
      r.onsuccess = () => {
        const t = r.result;
        if (!t || t.project_id !== project_id || t.deletedAt) {
          tx.failure = Object.assign(Error('티켓을 찾을 수 없습니다.'), {
            code: 'ticket_not_found',
          });
          tx.abort();
          return;
        }
        if (
          t.revision !== input.expected_revision ||
          ['working', 'review', 'done'].includes(t.status)
        ) {
          tx.failure = Object.assign(
            Error(
              t.goal
                ? '진행 중인 작업의 확정 목표는 변경할 수 없습니다. 변경 요청을 주석으로 남겨 주세요.'
                : '최신 티켓을 조회해 주세요.',
            ),
            { code: 'ticket_revision_conflict' },
          );
          tx.abort();
          return;
        }
        const sr = tx.objectStore('sessions').get(t.document_id);
        sr.onsuccess = () => {
          if (
            input.expected_edit_revision !== undefined &&
            (sr.result?.edit_revision || 0) !== input.expected_edit_revision
          ) {
            tx.failure = Object.assign(Error('목표를 만드는 동안 편집이 바뀌었습니다.'), {
              code: 'revision_conflict',
            });
            tx.abort();
            return;
          }
          const goal = {
            id: crypto.randomUUID(),
            title: t.title,
            document_id: t.document_id,
            image,
            request,
            request_unspecified: !request,
            source: metadata(input.source || {}, '출처'),
            annotations: metadata(input.annotations || {}, '주석'),
            selection: metadata(input.selection || [], '선택'),
            edit_revision: input.expected_edit_revision || 0,
            confirmed_at: now(),
            semantic_state: semanticState(sr.result || {}),
          };
          const next = {
            ...t,
            goal,
            thumbnail,
            status: 'queued',
            needs_reconfirmation: false,
            confirmation_held: false,
            revision_requested: false,
            revision: t.revision + 1,
            updated_at: now(),
          };
          tx.objectStore('tickets').put(next);
          done(next);
        };
      };
    },
  );
}
// Project names describe catalog contents; they do not authorize agent access.
export async function listTicketProjects() {
  const { listProjects } = await import('./project-model.js');
  return (await listProjects()).map((p) => p.id);
}
/** @param {string|undefined} project_id @param {any} options */
export async function listTickets(
  project_id,
  { status, limit = 50, offset = 0, query = '', deleted = false } = {},
) {
  if (project_id) projectKey(project_id);
  if (
    !Number.isInteger(limit) ||
    limit < 1 ||
    limit > 10000 ||
    !Number.isInteger(offset) ||
    offset < 0
  )
    invalid('목록 범위를 확인해 주세요.');
  if (
    status &&
    !['unfinished', 'all', 'ready'].includes(status) &&
    !Object.hasOwn(TICKET_STATES, status)
  )
    invalid('티켓 상태를 확인해 주세요.');
  return transact(['tickets', 'sessions', 'documents'], 'readonly', (tx, done) => {
    const r = tx.objectStore('tickets').getAll();
    r.onsuccess = () => {
      const rows = r.result
        .filter(
          (t) =>
            (!project_id || t.project_id === project_id) &&
            !!t.deletedAt === !!deleted &&
            (!status ||
              status === 'all' ||
              (status === 'unfinished'
                ? t.status !== 'done'
                : status === 'ready'
                  ? t.status === 'queued' && !t.needs_reconfirmation && !t.claim
                  : t.status === status)) &&
            (!query ||
              [t.title, t.display_id, t.goal?.request]
                .join(' ')
                .toLocaleLowerCase()
                .includes(query.toLocaleLowerCase())),
        )
        .sort((a, b) => b.updated_at.localeCompare(a.updated_at));
      const tickets = rows.slice(offset, offset + limit).map(({ goal, records, ...t }) => ({
        ...t,
        title: t.title || goal?.title,
        request: goal?.request || '',
        has_goal: !!goal,
        goal_id: goal?.id || null,
        record_count: records.length,
      }));
      for (const t of tickets) {
        const original = tx.objectStore('documents').get(t.document_id);
        original.onsuccess = () => {
          t.source_url = original.result?.url || '';
        };
        const sr = tx.objectStore('sessions').get(t.document_id);
        sr.onsuccess = () => {
          t.comment_count = Object.values(sr.result?.annotations || {}).filter(Boolean).length;
          t.edit_revision = sr.result?.edit_revision || 0;
          t.current_note = sr.result?.note || '';
          t.first_comment =
            Object.values(sr.result?.annotations || {}).find(
              (v) => typeof v === 'string' && v.trim(),
            ) || '';
          t.change_count =
            Object.keys(sr.result?.edits || {}).length + (sr.result?.resourceRepairs || []).length;
        };
      }
      done({
        total: rows.length,
        tickets,
        next_cursor: offset + limit < rows.length ? String(offset + limit) : null,
      });
    };
  });
}
export async function getTicket(ref, project_id, { includeDeleted = false } = {}) {
  if (project_id) projectKey(project_id);
  return transact(['tickets'], 'readonly', (tx, done) => {
    const r = tx.objectStore('tickets').getAll();
    r.onsuccess = () => {
      const rows = r.result.filter(
        (t) => (!project_id || t.project_id === project_id) && (includeDeleted || !t.deletedAt),
      );
      const exact = rows.filter((t) => t.id === ref || t.display_id === ref),
        found = exact.length ? exact : rows.filter((t) => t.title === ref);
      if (found.length > 1) {
        tx.failure = Object.assign(Error('같은 이름의 티켓이 여러 개입니다. ID로 선택해 주세요.'), {
          code: 'ambiguous_ticket',
          candidates: found.map((t) => ({
            id: t.id,
            display_id: t.display_id,
            title: t.title,
            project_id: t.project_id,
            status: t.status,
          })),
        });
        tx.abort();
        return;
      }
      done(found[0] || null);
    };
  });
}
const transitions = {
  draft: ['blocked'],
  queued: ['working', 'blocked'],
  working: ['review', 'blocked', 'queued'],
  review: ['done', 'queued', 'blocked'],
  done: ['queued'],
  blocked: ['draft', 'working', 'queued'],
};
export function applyTicketUpdate(ticket, patch) {
  if (ticket.revision !== patch.expected_revision)
    invalid('티켓이 변경됐습니다. 최신 상태를 조회해 주세요.', 'ticket_revision_conflict');
  const status = patch.status || ticket.status;
  if (
    !Object.hasOwn(TICKET_STATES, status) ||
    (status !== ticket.status && !transitions[ticket.status].includes(status))
  )
    invalid('허용하지 않는 상태 전환입니다.', 'invalid_transition');
  if (ticket.records.length >= 1000)
    invalid('티켓 기록 보관 한도입니다. 새 티켓에 후속 목표를 정리해 주세요.');
  if (!ticket.goal && !['draft', 'blocked'].includes(status))
    invalid('구현 전에 목표를 확정해 주세요.', 'goal_required');
  if (ticket.goal?.id && patch.goal_id !== ticket.goal.id)
    invalid('구현 목표가 일치하지 않습니다.', 'wrong_goal');
  if (
    status === 'working' &&
    ticket.status !== 'working' &&
    (ticket.needs_reconfirmation || ticket.confirmation_held)
  )
    invalid('편집 내용을 다시 확정해 주세요.', 'reconfirmation_required');
  if (ticket.claim && patch.claim_token !== ticket.claim.token)
    invalid('다른 작업자가 이미 착수했습니다. 최신 상태를 조회해 주세요.', 'claim_conflict');
  if (status === 'working' && !patch.claim_token)
    invalid('중복 착수를 막기 위한 claim_token이 필요합니다.', 'claim_required');
  const summary = text(patch.summary, '작업/검토 기록', 6000);
  if (status === 'working' && status !== ticket.status && !patch.implementation_instruction?.trim())
    invalid('사람의 구현 지시를 기록해 주세요.', 'instruction_required');
  if (status === 'review' && status !== ticket.status && (!patch.image || !patch.checks?.trim()))
    invalid('검토를 위해 구현 이미지와 검증 결과가 필요합니다.', 'evidence_required');
  if (
    status === 'done' &&
    status !== ticket.status &&
    (patch.review_decision !== 'approved' || !patch.review_note?.trim())
  )
    invalid('사람의 승인 내용이 필요합니다.', 'approval_required');
  const record = {
    id: crypto.randomUUID(),
    at: now(),
    status,
    summary,
    ...(ticket.goal?.id ? { goal_id: ticket.goal.id } : {}),
    ...(patch.image ? { image: patch.image } : {}),
    ...(patch.checks ? { checks: text(patch.checks, '검증 결과', 6000) } : {}),
    ...(patch.implementation_instruction
      ? { implementation_instruction: text(patch.implementation_instruction, '구현 지시', 3000) }
      : {}),
    ...(patch.review_decision
      ? {
          review_decision: patch.review_decision,
          review_note: text(patch.review_note, '검토 내용', 3000),
        }
      : {}),
  };
  return {
    ...ticket,
    status,
    revision: ticket.revision + 1,
    updated_at: record.at,
    records: [...ticket.records, record],
    confirmation_held: status === 'blocked' || (status === 'draft' && !!ticket.goal),
    claim: ['queued', 'done', 'blocked'].includes(status)
      ? null
      : ticket.claim ||
        (status === 'working'
          ? { token: patch.claim_token, goal_id: ticket.goal.id, at: record.at }
          : null),
  };
}
export async function updateTicket(input) {
  const project_id = projectKey(input.project_id),
    op = operation(input.operation_id);
  const patch = {
    ...input,
    ...(input.implementation_image_data_url
      ? { image: await ticketImage(input.implementation_image_data_url) }
      : {}),
  };
  delete patch.implementation_image_data_url;
  delete patch.operation_id;
  delete patch.editor_id;
  // Validate in the same read/write transaction as the CAS and operation receipt.
  return mutate('update:' + project_id + ':' + op, patch, (tx, done) => {
    const r = tx.objectStore('tickets').get(input.ticket_id);
    r.onsuccess = () => {
      try {
        if (!r.result || r.result.project_id !== project_id)
          invalid('이 프로젝트의 티켓을 찾을 수 없습니다.', 'ticket_not_found');
        const next = applyTicketUpdate(r.result, patch);
        tx.objectStore('tickets').put(next);
        done(next);
      } catch (e) {
        tx.failure = e;
        tx.abort();
      }
    };
  });
}

export async function prepareImplementation(input) {
  const project_id = projectKey(input.project_id),
    instruction = text(input.instruction, '구현 지시', 3000);
  const key = 'manifest:' + project_id + ':' + operation(input.operation_id);
  return transact(['tickets', 'operations'], 'readwrite', (tx, done) => {
    const receipt = tx.objectStore('operations').get(key);
    receipt.onsuccess = () => {
      if (receipt.result) {
        if (receipt.result.instruction !== instruction) {
          tx.failure = Object.assign(Error('다른 요청에 사용한 작업 ID입니다.'), {
            code: 'operation_id_reused',
          });
          tx.abort();
        } else done(receipt.result.result);
        return;
      }
      const read = tx.objectStore('tickets').getAll();
      read.onsuccess = () => {
        const tickets = read.result
          .filter(
            (t) =>
              t.project_id === project_id &&
              !t.deletedAt &&
              t.status === 'queued' &&
              t.goal &&
              !t.claim &&
              !t.needs_reconfirmation,
          )
          .map((t) => ({
            id: t.id,
            display_id: t.display_id,
            title: t.title,
            revision: t.revision,
            goal_id: t.goal.id,
          }));
        const result = {
          id: crypto.randomUUID(),
          project_id,
          instruction,
          tickets,
          created_at: now(),
        };
        tx.objectStore('operations').put({ id: key, instruction, result });
        done(result);
      };
    };
  });
}
