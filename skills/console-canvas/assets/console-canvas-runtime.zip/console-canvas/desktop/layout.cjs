const HEADER_HEIGHT = Object.freeze({
  source: 100,
  editor: 54,
  tickets: 54,
  settings: 54,
  agent: 54,
  update: 54,
  capture: 54,
});
module.exports = { HEADER_HEIGHT };
