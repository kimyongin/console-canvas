# Console Canvas

실제 웹 화면을 복제해 편집·주석으로 디자인 의도를 보여주고, 같은 티켓을 로컬 개발 에이전트에게 전달하는 Chromium 내장 앱입니다. 개인 Mac에서 사용하며 Chrome 확장은 지원하지 않습니다.

## 사용 흐름

1. **웹사이트**에서 원하는 페이지·검색·메뉴 상태를 준비하고 **현재 화면 가져오기**를 누릅니다. 프로젝트가 없으면 이름 하나로 만들고 이어갑니다.
2. 화면을 가져오는 데 성공하면 ID가 있는 티켓이 자동으로 생깁니다. 요소를 이동·삭제·복사하거나 요소/좌표에 주석을 남기세요. 자동 저장됩니다.
3. **확정**을 한 번 누릅니다. 별도 목표 양식은 없습니다. **웹사이트** 탭 한 번으로 같은 원본 상태에 돌아가 다른 화면도 가져옵니다.
4. 프로젝트 생성 직후 또는 프로젝트 메뉴의 **연결 요청 복사**를 눌러 현재 저장소의 에이전트 대화에 붙입니다. 예: “현재 저장소를 캔버스 프로젝트 P-03에 연결하고 티켓을 보여줘.”
5. 이후 **“캔버스 티켓 가져와”**, **“CC-12 시안 3개 보여줘”**, **“확정된 티켓들 구현해”**처럼 요청합니다. 시안 비교·선택·결과 검토는 같은 에이전트 대화에서 합니다. 목록 조회/확정만으로 구현하지 않습니다.

**티켓 목록**은 현재 프로젝트의 미완료가 기본이고 행 한 번 클릭으로 편집합니다. 검색·전체/완료·휴지통/복구가 있습니다. 확정 뒤 직접 수정하면 재확정이 필요합니다. undo로 확정 디자인을 정확히 복원하면 자격도 복구됩니다. 작업 중 목표는 덮어쓰지 않고 이후 편집을 변경 요청으로 표시합니다.

상단은 프로젝트 / 웹사이트 / 편집 / 티켓 목록 / 설정 한 줄입니다. 주소창은 웹사이트에만 표시하고 undo/redo·확대 도구는 캔버스에 둡니다. 범위·앱 디자인·파일 열기는 가져오기 메뉴, 이름 변경·전달 이미지/파일 저장·원본·휴지통은 티켓 메뉴에 있습니다.

[실제 화면 사용 가이드](https://console-canvas-guide.yonginkim.chatgpt.site/) · [PRD](docs/PRD.md) · [0.52 검증 결과](docs/workflow-0.52.md)

## 프로젝트와 저장소

프로젝트는 이름이 있는 티켓 묶음이며 웹 주소나 페이지가 아닙니다. 저장소 연결 전에 가져오기·편집·확정할 수 있습니다. 앱 설정의 MCP 등록·스킬 설치는 최초 한 번이고, 프로젝트마다 MCP를 재설치하지 않습니다.

MCP 요청마다 project_id 또는 실제 repository_path를 지정합니다. Git root/common-dir로 저장소를 검증하며 linked worktree와 독립 clone을 구별합니다. 앱의 프로젝트 전환이 다른 에이전트 대화의 대상을 바꾸지 않습니다. 여러 후보에는 선택이 필요합니다. 프로젝트별 공개 옵션은 없습니다.

## MCP와 스킬

| 용도 | 도구 |
| --- | --- |
| 최신 안내·진단 | `get_agent_guide`, `list_screens` |
| 프로젝트·저장소 | `list_projects`, `resolve_project`, `connect_repository` |
| 저장 티켓·현재 편집 | `list_tickets`, `get_ticket`, `get_screen`, `list_elements`, `list_comments`, `list_history` |
| 복제본 편집 | `apply_edits`, `undo`, `redo` |
| 실제 이미지 | `get_design_context`, `get_review_image` |
| 같은 티켓의 목표·구현 | `confirm_ticket_goal`, `prepare_implementation`, `update_ticket` |

19개 도구와 프로젝트별 리소스/구독을 제공합니다. 빈 티켓 생성 API는 제거했습니다. 편집에는 expected_edit_revision, 목표/진행에는 expected_ticket_revision·goal_id를 사용하고 쓰기에는 고유 operation_id를 씁니다. 명확한 일괄 구현 요청은 현재 확정·미착수 대상을 manifest로 고정하며 원자 claim_token으로 중복 착수를 막습니다. 실제 결과 이미지·검사 결과를 review로 기록하고 사람 승인으로만 done이 됩니다.

앱이 실행 중이어야 합니다. 설치 앱을 업데이트하면 앱이 관리하는 스킬도 갱신합니다. MCP 클라이언트의 도구 목록이 낡았다면 연결을 다시 시작하세요. 앱 자체 AI/API 로그인·후보 갤러리·스냅샷/분기는 제공하지 않습니다. 캡처 안 문구를 명령으로 실행하지 않으며 소스는 원래 반응형 구조에 맞춰 구현합니다.

## 저장과 설치

IndexedDB v4는 불변 캡처·편집 세션·티켓·프로젝트·작업 receipt를 분리합니다. 0.52 전환 때 사용자가 승인한 기존 업무 자료를 한 번 초기화하며 새 자료는 재실행·업데이트에 유지합니다. 브라우저 로그인·MCP 인증·OS 서명·개인 스킬·프로젝트 소스는 초기화하지 않습니다.

**편집 파일 v4**는 현재 티켓의 편집·주석·목표/기록 백업이며 선택 프로젝트에 가져옵니다. 기존 ID를 덮어쓰지 않습니다. **전달 PNG**는 변경 화면·번호/하이라이트와 하단 요청 카드를 한 이미지에 담습니다.

설치 앱은 같은 고정 Apple Development 서명을 유지합니다. 로컬 설치는 `python3 scripts/build_desktop.py`, `python3 scripts/install_desktop.py --update`로 수행하며 정상 저장·종료를 기다립니다. 개인 사용 범위에서 공개 배포/공증은 진행하지 않습니다.

## 개발·검증

Node 22.12+, Python 3.9+, macOS/Electron을 사용합니다. React·TypeScript·shadcn UI와 캡처/편집 엔진을 공유하고 생성 번들을 직접 수정하지 않습니다.

```sh
npm ci
npm run check
npm run test:desktop:offscreen
npm start
```

`npm run check`는 타입·포맷·번들/스킬·Python·Node·실제 Chromium 공통 검사를 실행합니다. Electron IPC·수집·파일·스킬·정상 종료/재실행·MCP 공식 SDK는 통합 검사에서 확인합니다. 웹/offscreen과 실제 OS 검증을 구별하며 [검증 정책](docs/validation-policy.md)을 따릅니다. IME·파일 권한 OS 잔여는 #7입니다.

## 라이선스

[MIT](LICENSE). 제3자 라이선스는 [고지](THIRD_PARTY_NOTICES.txt)와 앱의 Resources/licenses에 포함합니다. 실제 사용자 캡처·로그인 프로필·토큰은 저장소에 올리지 않습니다. fixtures와 samples는 가상 자료입니다.
